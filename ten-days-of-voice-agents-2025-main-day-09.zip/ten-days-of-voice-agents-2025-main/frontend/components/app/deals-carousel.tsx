'use client';

import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Tag, Lightning } from '@phosphor-icons/react/dist/ssr';

interface Deal {
  id: string;
  name: string;
  price: number;
  originalPrice: number;
  description: string;
}

const DEALS: Deal[] = [
  {
    id: 'mob-001',
    name: 'Apple iPhone 15',
    price: 79900,
    originalPrice: 89900,
    description: 'Dynamic Island. 48MP Main Camera.',
  },
  {
    id: 'mob-002',
    name: 'Samsung Galaxy S24 Ultra',
    price: 129999,
    originalPrice: 134999,
    description: 'Galaxy AI is here. Titanium Frame.',
  },
  {
    id: 'fash-001',
    name: 'Nike Air Jordan 1 Low',
    price: 8995,
    originalPrice: 10995,
    description: 'Premium leather. Iconic style.',
  },
];

export function DealsCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % DEALS.length);
    }, 5000); // Rotate every 5 seconds
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative w-full overflow-hidden rounded-lg bg-[#2874F0] text-white shadow-md">
      <div className="absolute inset-0 opacity-10"
        style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '20px 20px' }}
      />

      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.4 }}
          className="relative flex items-center justify-between px-4 py-3 md:px-8 md:py-4"
        >
          {/* Left: Branding */}
          <div className="hidden flex-col md:flex">
            <div className="flex items-center gap-1 text-[#FFE500]">
              <Lightning weight="fill" className="h-5 w-5" />
              <span className="text-lg font-black italic tracking-wider uppercase">Big Billion Days</span>
            </div>
            <span className="text-xs font-medium text-blue-100">Special Offers Ending Soon</span>
          </div>

          {/* Center: Product Info */}
          <div className="flex flex-1 flex-col items-start px-4 md:items-center md:text-center">
            <h3 className="text-lg font-bold leading-tight md:text-2xl">
              {DEALS[currentIndex].name}
            </h3>
            <p className="text-xs font-medium text-blue-100 md:text-sm">
              {DEALS[currentIndex].description}
            </p>
          </div>

          {/* Right: Price & CTA */}
          <div className="flex flex-col items-end">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-[#FFE500]">
                ₹{DEALS[currentIndex].price.toLocaleString()}
              </span>
              <span className="hidden text-sm text-blue-200 line-through md:inline">
                ₹{DEALS[currentIndex].originalPrice.toLocaleString()}
              </span>
            </div>
            <span className="rounded bg-[#FFE500] px-2 py-0.5 text-[10px] font-bold text-[#2874F0]">
              {Math.round(((DEALS[currentIndex].originalPrice - DEALS[currentIndex].price) / DEALS[currentIndex].originalPrice) * 100)}% OFF
            </span>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Progress Indicators */}
      <div className="absolute bottom-1 left-1/2 flex -translate-x-1/2 gap-1">
        {DEALS.map((_, idx) => (
          <div
            key={idx}
            className={`h-1 rounded-full transition-all duration-300 ${idx === currentIndex ? 'w-6 bg-[#FFE500]' : 'w-1 bg-white/30'
              }`}
          />
        ))}
      </div>
    </div>
  );
}
