'use client';

import React, { useEffect, useRef, useState } from 'react';
import { DataPacket_Kind, RemoteParticipant, RoomEvent } from 'livekit-client';
import { motion } from 'motion/react';
import { useRoomContext } from '@livekit/components-react';
import type { AppConfig } from '@/app-config';
import { ChatTranscript } from '@/components/app/chat-transcript';
import { ImageViewer } from '@/components/app/image-viewer';
import { PreConnectMessage } from '@/components/app/preconnect-message';
import { TileLayout } from '@/components/app/tile-layout';
import {
  AgentControlBar,
  type ControlBarControls,
} from '@/components/livekit/agent-control-bar/agent-control-bar';
import { useChatMessages } from '@/hooks/useChatMessages';
import { useConnectionTimeout } from '@/hooks/useConnectionTimout';
import { useDebugMode } from '@/hooks/useDebug';
import { cn } from '@/lib/utils';
import { ScrollArea } from '../livekit/scroll-area/scroll-area';
import { Button } from '@/components/livekit/button';
import { ArrowClockwise, CaretDown, MagnifyingGlass, ShoppingCart } from '@phosphor-icons/react/dist/ssr';

/* eslint-disable @typescript-eslint/no-explicit-any */

const MotionBottom = motion.create('div');

const IN_DEVELOPMENT = process.env.NODE_ENV !== 'production';
const BOTTOM_VIEW_MOTION_PROPS = {
  variants: {
    visible: {
      opacity: 1,
      translateY: '0%',
    },
    hidden: {
      opacity: 0,
      translateY: '100%',
    },
  },
  initial: 'hidden',
  animate: 'visible',
  exit: 'hidden',
  transition: {
    duration: 0.3,
    delay: 0.5,
    ease: 'easeOut',
  } as any,
};

interface FadeProps {
  top?: boolean;
  bottom?: boolean;
  className?: string;
}

export function Fade({ top = false, bottom = false, className }: FadeProps) {
  return (
    <div
      className={cn(
        'from-background pointer-events-none h-4 bg-linear-to-b to-transparent',
        top && 'bg-linear-to-b',
        bottom && 'bg-linear-to-t',
        className
      )}
    />
  );
}
interface SessionViewProps {
  appConfig: AppConfig;
}

import { DealsCarousel } from '@/components/app/deals-carousel';

// ... imports

export const SessionView = ({
  appConfig,
  ...props
}: React.ComponentProps<'section'> & SessionViewProps) => {
  useConnectionTimeout(200_000);
  useDebugMode({ enabled: IN_DEVELOPMENT });

  const room = useRoomContext();
  const messages = useChatMessages();
  const [chatOpen, setChatOpen] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const [generatedImage, setGeneratedImage] = useState<{ url: string; prompt: string } | null>(
    null
  );

  const controls: ControlBarControls = {
    leave: true,
    microphone: true,
    chat: appConfig.supportsChatInput,
    camera: appConfig.supportsVideoInput,
    screenShare: appConfig.supportsVideoInput,
  };

  useEffect(() => {
    const lastMessage = messages.at(-1);
    const lastMessageIsLocal = lastMessage?.from?.isLocal === true;

    if (scrollAreaRef.current && lastMessageIsLocal) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  useEffect(() => {
    const onDataReceived = (
      payload: Uint8Array,
      participant?: RemoteParticipant,
      kind?: DataPacket_Kind,
      topic?: string
    ) => {
      if (topic === 'agent_events') {
        try {
          const parsedPayload = JSON.parse(new TextDecoder().decode(payload));
          if (parsedPayload.type === 'image') {
            setGeneratedImage(parsedPayload.data);
          }
        } catch (e) {
          console.error('Failed to parse agent event:', e);
        }
      }
    };

    room.on(RoomEvent.DataReceived, onDataReceived);
    return () => {
      room.off(RoomEvent.DataReceived, onDataReceived);
    };
  }, [room]);

  const handleRestart = async () => {
    window.location.reload();
  };

  return (
    <section className="relative flex h-full w-full flex-col overflow-hidden bg-[#F1F3F6] font-sans text-slate-900 selection:bg-[#FFE500] selection:text-[#2874F0]" {...props}>
      {/* Flipkart Navbar */}
      <nav className="z-50 flex h-16 w-full items-center gap-4 bg-[#2874F0] px-4 shadow-md md:px-12">
        {/* Logo */}
        <div className="flex flex-col items-end">
          <span className="text-xl font-bold italic tracking-tight text-white">Flipkart</span>
          <div className="flex items-center gap-0.5 text-[10px] italic text-slate-200">
            Explore <span className="font-bold text-[#FFE500]">Plus</span>
            <span className="text-[#FFE500]">+</span>
          </div>
        </div>

        {/* Search Bar (Visual Only) */}
        <div className="hidden max-w-xl flex-1 items-center rounded-sm bg-white px-4 py-2 shadow-sm md:flex">
          <input
            type="text"
            placeholder="Search for products, brands and more"
            className="w-full bg-transparent text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none"
            disabled
          />
          <MagnifyingGlass className="h-5 w-5 text-[#2874F0]" />
        </div>

        {/* Nav Items */}
        <div className="ml-auto flex items-center gap-6 text-white">
          <button className="hidden bg-white px-8 py-1 text-sm font-bold text-[#2874F0] shadow-sm transition-transform hover:scale-105 md:block">
            Login
          </button>
          <div className="hidden items-center gap-1 text-sm font-bold md:flex">
            <span>Become a Seller</span>
          </div>
          <div className="hidden items-center gap-1 text-sm font-bold md:flex">
            <span>More</span>
            <CaretDown className="h-3 w-3" weight="bold" />
          </div>
          <div className="flex items-center gap-2 font-bold">
            <ShoppingCart className="h-6 w-6" weight="fill" />
            <span className="hidden md:inline">Cart</span>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <div className="relative flex flex-1 flex-col overflow-hidden">
        {/* Deals Banner (Top) */}
        <div className="z-20 w-full bg-white p-2 shadow-sm">
          <DealsCarousel />
        </div>

        {/* Chat Transcript Area */}
        <div className="relative flex-1 min-h-0">
          <ScrollArea ref={scrollAreaRef} className="h-full px-4 pb-40 pt-4 md:px-6">
            <ChatTranscript
              hidden={!chatOpen}
              messages={messages}
              className="mx-auto max-w-3xl space-y-4"
            />
          </ScrollArea>

          {/* Visualizer Container (Centered Overlay) */}
          <div className="absolute inset-0 z-0 flex items-center justify-center pointer-events-none">
            <div className="pointer-events-auto w-full h-full">
              <TileLayout chatOpen={chatOpen} />
            </div>
          </div>
        </div>

        {/* Image Viewer Overlay */}
        <ImageViewer
          imageUrl={generatedImage?.url ?? null}
          prompt={generatedImage?.prompt ?? null}
          onClose={() => setGeneratedImage(null)}
        />
      </div>

      {/* Bottom Controls */}
      <MotionBottom
        {...BOTTOM_VIEW_MOTION_PROPS}
        className="fixed inset-x-0 bottom-0 z-50 bg-white/80 backdrop-blur-md border-t border-slate-200 p-4 pb-6"
      >
        <div className="mx-auto flex w-full max-w-3xl flex-col gap-4">
          {appConfig.isPreConnectBufferEnabled && (
            <PreConnectMessage messages={messages} className="mx-auto" />
          )}

          <div className="flex items-center justify-between gap-4">
            <div className="flex-1">
              <AgentControlBar controls={controls} onChatOpenChange={setChatOpen} />
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleRestart}
              className="text-slate-500 hover:text-[#2874F0] hover:bg-blue-50 rounded-full"
              title="Restart Session"
            >
              <ArrowClockwise className="h-6 w-6" />
            </Button>
          </div>

          <div className="text-center">
            <p className="text-[10px] font-bold tracking-widest text-slate-400 uppercase">
              Flipkart Voice Assistant • Powered by LiveKit
            </p>
          </div>
        </div>
      </MotionBottom>
    </section>
  );
};
