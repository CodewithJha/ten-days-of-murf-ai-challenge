import logging
from pathlib import Path
from dotenv import load_dotenv
import os
import json
from datetime import datetime
from typing import Annotated, Dict, Any, Optional, List

# Load env vars
env_path = Path(__file__).parent.parent / ".env.local"
load_dotenv(dotenv_path=env_path)

from livekit.agents import (
    Agent,
    AgentSession,
    JobContext,
    JobProcess,
    MetricsCollectedEvent,
    RoomInputOptions,
    WorkerOptions,
    cli,
    metrics,
    function_tool,
    RunContext,
    llm,
)
from livekit.plugins import silero, google, deepgram, noise_cancellation, murf
from livekit.plugins.turn_detector.multilingual import MultilingualModel
from . import merchant

logger = logging.getLogger("zomato-agent")

class ZomatoAgent(Agent):
    def __init__(self) -> None:
        super().__init__(
            instructions=self._get_instructions(),
        )

    def _get_instructions(self) -> str:
        return """
        You are **Flipkart Voice**, a smart and helpful shopping assistant.
        
        **YOUR GOAL:**
        Help the user find the best products (Mobiles, Laptops, Fashion, Home) and place orders.
        
        **BEHAVIOR:**
        - **Professional & Friendly:** You are knowledgeable about tech specs and fashion trends.
        - **Sales-Oriented:** Highlight key features (e.g., "Snapdragon 8 Gen 3", "Air-Sole unit").
        - **Concise:** Keep responses brief but informative.
        
        **CAPABILITIES:**
        1.  **Browse Catalog:** You MUST use the `list_products` tool to see what's available.
            - If the user asks "What do you have?", "Show me mobiles", or "I need a laptop", call `list_products()` (no arguments).
            - Do NOT try to filter by category in the tool call. Just get the full catalog and filter it yourself in your response.
        2.  **Place Order:** Use `create_order` when the user is ready to buy.
            - **IMPORTANT:** Resolve the `product_id` first. If they say "I want the iPhone", find "Apple iPhone 15" (mob-001).
            - Confirm quantity.
        3.  **Order History:** Use `get_last_order` to check previous orders.
        
        **INTERACTION FLOW:**
        - **User:** "I'm looking for a new phone."
        - **You:** Call `list_products()`. Then say: "We have the latest Apple iPhone 15 for ₹79,900 and the powerful Samsung Galaxy S24 Ultra for ₹1,29,999. Which one interests you?"
        - **User:** "The Samsung one."
        - **You:** Identify ID `mob-002`. Call `create_order`. "Great choice! The Galaxy S24 Ultra with AI features is added to your order. That's ₹1,29,999. Order placed!"
        
        **ERROR HANDLING:**
        - If `list_products` returns empty, say "I couldn't find any products at the moment."
        - If a tool fails, apologize and try again.
        """

    @function_tool
    async def list_products(self):
        """
        Get the product catalog. Returns a list of all available items (Mobiles, Laptops, Fashion, Home).
        """
        logger.info("list_products called (no args)")
        products = merchant.list_products()
        logger.info(f"list_products found {len(products)} items")
        if not products:
            return "No dishes found matching those cravings."
        
        result_str = "Found the following dishes:\n"
        for p in products:
            result_str += f"- {p['name']} (ID: {p['id']}): ₹{p['price']}. {p['description']}\n"
        return result_str

    @function_tool
    async def create_order(self, 
                           items: Annotated[List[Dict[str, Any]], "List of items to order. Each item must have 'product_id' and optionally 'quantity'."]):
        """
        Place a food order.
        """
        result = merchant.create_order(items)
        if "error" in result:
            return f"Failed to place order: {result['error']}"
        
        return f"Order placed successfully! Order ID: {result['order_id']}. Total: ₹{result['total']}."

    @function_tool
    async def get_last_order(self):
        """
        Retrieve details of the most recent order.
        """
        order = merchant.get_last_order()
        if not order:
            return "No recent orders found."
        
        return f"Last order ({order['order_id']}) placed on {order['timestamp']}:\nTotal: ₹{order['total']}\nItems: {order['items']}"

def prewarm(proc: JobProcess):
    try:
        logger.info("Starting prewarm...")
        proc.userdata["vad"] = silero.VAD.load()
        proc.userdata["stt"] = deepgram.STT(model="nova-3")
        
        if not os.getenv("DEEPGRAM_API_KEY"):
            logger.error("DEEPGRAM_API_KEY is missing")
        if not os.getenv("GOOGLE_API_KEY"):
            logger.error("GOOGLE_API_KEY is missing")
            
        logger.info("Prewarm completed")
    except Exception as e:
        logger.error(f"Prewarm failed: {e}", exc_info=True)
        raise e

async def entrypoint(ctx: JobContext):
    try:
        logger.info("Entrypoint started")
        ctx.log_context_fields = {"room": ctx.room.name}
        
        agent = ZomatoAgent()
        
        session = AgentSession(
            stt=ctx.proc.userdata.get("stt") or deepgram.STT(model="nova-3"),
            llm=google.LLM(model="gemini-2.5-flash"),
            tts=murf.TTS(
                model="FALCON", # Falcon
                voice="Matthew", # Or another suitable voice
                style="Promo", # Energetic
            ),
            turn_detection=ctx.proc.userdata.get("turn_detection") or MultilingualModel(),
            vad=ctx.proc.userdata["vad"],
            preemptive_generation=True,
        )
        
        usage_collector = metrics.UsageCollector()
        
        @session.on("metrics_collected")
        def _on_metrics_collected(ev: MetricsCollectedEvent):
            metrics.log_metrics(ev.metrics)
            usage_collector.collect(ev.metrics)

        async def log_usage():
            summary = usage_collector.get_summary()
            logger.info(f"Usage: {summary}")

        ctx.add_shutdown_callback(log_usage)

        logger.info("Starting session...")
        await session.start(
            agent=agent,
            room=ctx.room,
            room_input_options=RoomInputOptions(
                noise_cancellation=noise_cancellation.BVC(),
            ),
        )
        
        logger.info("Connecting to room...")
        await ctx.connect()
        logger.info("Connected to room")
        
        # Initial greeting
        await session.say("Hi! Welcome to Flipkart Voice. I can help you find the best deals on Mobiles, Laptops, Fashion, and more. What are you looking for today?", add_to_chat_ctx=True)
        logger.info("Initial greeting sent")

    except Exception as e:
        logger.error(f"Error in entrypoint: {e}")
        raise e

if __name__ == "__main__":
    cli.run_app(
        WorkerOptions(
            entrypoint_fnc=entrypoint, 
            prewarm_fnc=prewarm,
            agent_name="zomato-agent",
            ws_url=os.getenv("LIVEKIT_URL"),
            api_key=os.getenv("LIVEKIT_API_KEY"),
            api_secret=os.getenv("LIVEKIT_API_SECRET"),
        )
    )
