# The Tank 🦈💰

**"Who are you? And what is your ask?"**

Welcome to **The Tank**, an AI-powered investment simulation where you pitch your business idea to a ruthless "Shark" investor. Powered by **LiveKit** and **Gemini 2.5 Flash**, this agent analyzes your pitch, calculates your valuation in real-time, and decides whether to invest or say "I'm out."

## 🚀 Day 10: The Shark Tank Rebrand

For the final day of the Voice Agent Challenge, we transformed the application into a high-stakes business negotiation simulator.

### Key Features
-   **The Shark Persona**: A tough, analytical investor who grills you on sales, margins, and CAC.
-   **Real-Time Valuation**: The agent instantly calculates your company's valuation based on your ask (e.g., "$100k for 10%" = $1M Valuation).
-   **Deal Logic**: Tracks the negotiation state (Pitch -> Numbers -> Offer -> Deal/No Deal).
-   **REST API Integration**: A FastAPI backend that exposes deal data and shark profiles, demonstrating hybrid Agent + API architecture.
-   **Premium UI**: A "Shark Tank" inspired aesthetic with Deep Blue and Gold themes.

## 🛠️ Tech Stack

-   **Backend**: Python, LiveKit Agents, FastAPI
-   **AI Models**:
    -   **LLM**: Google Gemini 2.5 Flash (The Brain)
    -   **STT**: Deepgram Nova-3 (The Ears)
    -   **TTS**: **Murf Falcon** (The Voice - "Matthew" for authority)
-   **Frontend**: Next.js 15, Tailwind CSS, LiveKit Components

## 🚀 Quick Start

### Prerequisites
-   Python 3.9+ with `uv`
-   Node.js 18+ with `pnpm`
-   LiveKit Cloud Account

### 1. Start the Application
We have simplified the startup process into a single script:

```bash
./start_app.sh
```
This will start:
-   **Backend Agent**: The Shark Persona
-   **Frontend**: The User Interface

### 2. Start the REST API (Optional)
To see the deal data:
```bash
cd backend
uv run python -m src.api
```
Access the API docs at: `http://localhost:8000/docs`

### 3. Enter the Tank
Open `http://localhost:3000`, enter your name, and click **"Enter the Tank"**.

## 🎮 Interaction Examples

-   **Shark**: "Who are you and what is your ask?"
-   **You**: "I'm asking for $100,000 for 10% equity."
-   **Shark**: "That values your company at $1 Million. Do you have the sales to back that up?"
-   **You**: "We have $500,000 in sales this year."
-   **Shark**: "Impressive. I'm willing to make an offer."

## 📜 License
MIT
