#!/bin/bash
echo "Starting LiveKit Server (Localhost)..."
docker run --rm \
    -p 7880:7880 \
    -p 7881:7881 \
    -p 7882:7882/udp \
    livekit/livekit-server \
    --dev \
    --bind 0.0.0.0
