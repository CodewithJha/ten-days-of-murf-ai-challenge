# 🛒 Day 8: Reimagining Quick Commerce with Voice AI (Meet NOVA!) ⚡

"Groceries in 10 minutes? Just ask."

I'm excited to share my Day 8 build for the **Murf AI Voice Agent Challenge**! 🏆

I rebuilt the **Blinkit** experience as a voice-first app, powered by a hyper-intelligent agent named **NOVA** (Neural Online Voice Assistant).

For the voice, I'm using **Murf Falcon**, the fastest TTS API out there. The latency is incredible, making NOVA feel truly conversational and ultra-realistic. 🗣️💨

## 🚀 Key Features

🧠 **Smart Semantic Search**: 
NOVA understands context. Ask for "healthy snacks," and she finds fruits and nuts—even if the word "healthy" isn't in the name.

👤 **Hyper-Personalization**: 
Tell her "I'm vegan," and she adapts instantly, filtering out dairy and meat.

⚡ **Quantum Delivery**: 
A restored Blinkit Green & Yellow UI that visualizes the voice experience in real-time.

## 🛠️ The Tech Stack

-   **TTS**: **Murf Falcon** (The star of the show! 🌟)
-   **Orchestration**: LiveKit Agents
-   **LLM**: Google Gemini 2.5 Flash
-   **STT**: Deepgram Nova-3
-   **Frontend**: Next.js 15 + Tailwind CSS

I'm building this as part of the **“Murf AI Voice Agent Challenge”**. Big shoutout to the team at @Murf AI for pushing the boundaries of voice tech!

Check out the code on GitHub! 👇
[Link in comments]

#MurfAIVoiceAgentsChallenge #10DaysofAIVoiceAgents #VoiceAI #LiveKit #Gemini #BuildInPublic #Blinkit #QuickCommerce #AI
