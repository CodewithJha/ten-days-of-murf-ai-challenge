# 🛒 Day 8: Reimagining Quick Commerce with Voice AI (Meet NOVA!) ⚡

"Groceries in 10 minutes? Just ask." 

For Day 8 of my **10 Days of Voice Agents** challenge, I decided to tackle something we use every day: **Quick Commerce**. 

I rebuilt the **Blinkit** experience as a voice-first app, powered by a hyper-intelligent agent named **NOVA** (Neural Online Voice Assistant). 

This isn't just a chatbot. NOVA is witty, context-aware, and fast. 

## 🚀 Key Features

🧠 **Smart Semantic Search**: 
I implemented a "vector-lite" search engine. If you ask for *"healthy snacks"*, NOVA understands you mean fruits, nuts, and veggies—even if the word "healthy" isn't in the product name.

👤 **Hyper-Personalization**: 
NOVA remembers context. Tell her *"I'm vegan"*, and she’ll automatically filter out dairy and meat from all future search results. She adapts to *you*.

⚡ **Quantum Delivery**: 
A futuristic UI (restored to the classic Blinkit Green & Yellow) that visualizes your voice and simulates the 10-minute delivery promise.

## 🛠️ The Tech Stack

-   **Orchestration**: LiveKit Agents (The backbone of real-time interaction)
-   **LLM**: Google Gemini 2.5 Flash (For reasoning and wit)
-   **TTS**: Murf Falcon (Ultra-realistic, low-latency voice)
-   **STT**: Deepgram Nova-3 (Instant transcription)
-   **Frontend**: Next.js 15 + Tailwind CSS + Framer Motion

## 💡 Why Voice for Commerce?
Typing "milk, eggs, bread" is fast. But saying *"Get me the usual breakfast stuff, but make it vegan today"* is faster. Voice AI bridges the gap between intent and action.

Check out the code on GitHub! 👇
[Link in comments]

#VoiceAI #LiveKit #Gemini #BuildInPublic #Blinkit #QuickCommerce #AI #Python #NextJS #10DaysOfAI
