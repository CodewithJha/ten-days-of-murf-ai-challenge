export interface Product {
    id: string;
    name: string;
    price: string;
    category: string;
    image: string;
    tag?: string;
    color?: string;
}

export const PRODUCTS: Product[] = [
    {
        id: "NKE-001",
        name: "Nike Air Zoom Pegasus 41",
        price: "₹11,895",
        category: "Running",
        image: "https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/37b25696-9486-4297-96c3-162747353915/air-zoom-pegasus-41-road-running-shoes-RZm89S.png",
        tag: "BEST SELLER",
        color: "bg-[#D0F224]"
    },
    {
        id: "NKE-002",
        name: "Nike Vaporfly 3",
        price: "₹20,695",
        category: "Racing",
        image: "https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/571e8606-25d2-45e0-9b37-290827254552/vaporfly-3-road-racing-shoes-xsDgvM.png",
        tag: "FASTEST",
        color: "bg-orange-500"
    },
    {
        id: "NKE-003",
        name: "Air Jordan 1 Retro High OG",
        price: "₹16,995",
        category: "Lifestyle",
        image: "https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/9b26aa8f-0173-409b-b30a-7ce2d88573a4/air-jordan-1-retro-high-og-shoes-Pz6lzc.png",
        tag: "ICON",
        color: "bg-red-600"
    },
    {
        id: "NKE-004",
        name: "Nike Dunk Low Retro",
        price: "₹8,695",
        category: "Lifestyle",
        image: "https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/b1bcbca4-e853-4df7-b329-5be3c61ee057/dunk-low-retro-shoe-66RGqF.png",
        tag: "TRENDING",
        color: "bg-blue-500"
    },
    {
        id: "NKE-005",
        name: "LeBron XXI",
        price: "₹18,395",
        category: "Basketball",
        image: "https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/e777c881-5b62-4250-92a6-362967f54cca/lebron-xxi-basketball-shoes-ln3T04.png",
        tag: "KING",
        color: "bg-purple-600"
    },
    {
        id: "NKE-006",
        name: "Nike Tech Fleece",
        price: "₹8,495",
        category: "Apparel",
        image: "https://static.nike.com/a/images/t_PDP_1728_v1/f_auto,q_auto:eco/024d2626-8666-4172-981b-b139d6d333d2/sportswear-tech-fleece-windrunner-full-zip-hoodie-5z1q1z.png",
        tag: "WINTER",
        color: "bg-gray-500"
    }
];
