'use client';

import React, { useEffect, useRef, useState } from 'react';
import { useRoomContext } from '@livekit/components-react';
import type { AppConfig } from '@/app-config';
import { ChatTranscript } from '@/components/app/chat-transcript';
import { TileLayout } from '@/components/app/tile-layout';
import {
  AgentControlBar,
  type ControlBarControls,
} from '@/components/livekit/agent-control-bar/agent-control-bar';
import { useChatMessages } from '@/hooks/useChatMessages';
import { useConnectionTimeout } from '@/hooks/useConnectionTimout';
import { useDebugMode } from '@/hooks/useDebug';
import { Button } from '@/components/livekit/button';
import { ArrowClockwise, CurrencyDollar } from '@phosphor-icons/react/dist/ssr';

interface SessionViewProps {
  appConfig: AppConfig;
}

export const SessionView = ({
  appConfig,
  ...props
}: React.ComponentProps<'section'> & SessionViewProps) => {
  useConnectionTimeout(200_000);
  useDebugMode({ enabled: process.env.NODE_ENV !== 'production' });

  const room = useRoomContext();
  const messages = useChatMessages();
  const [chatOpen, setChatOpen] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  const controls: ControlBarControls = {
    leave: true,
    microphone: true,
    chat: appConfig.supportsChatInput,
    camera: appConfig.supportsVideoInput,
    screenShare: appConfig.supportsVideoInput,
  };

  useEffect(() => {
    const lastMessage = messages.at(-1);
    const lastMessageIsLocal = lastMessage?.from?.isLocal === true;

    if (scrollAreaRef.current && lastMessageIsLocal) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  const handleRestart = async () => {
    window.location.reload();
  };

  return (
    <section className="relative flex h-full w-full flex-col overflow-hidden bg-background font-sans text-foreground shark-gradient" {...props}>
      {/* Shark Tank Header */}
      <nav className="relative z-20 flex h-16 items-center justify-between bg-card/50 px-4 shadow-sm md:px-6 border-b border-primary/20 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-background shadow-sm border border-primary/50">
            <CurrencyDollar size={24} weight="fill" />
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-black tracking-tighter text-gold font-serif">THE <span className="text-foreground">TANK</span></span>
            <span className="text-[10px] font-bold tracking-wide text-muted-foreground uppercase leading-none">Investment Session</span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="px-3 py-1 rounded-full bg-destructive/10 border border-destructive/30 text-xs font-bold text-destructive animate-pulse">
            RECORDING
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <div className="relative flex flex-1 flex-col overflow-hidden">

        {/* Visualizer Container (Centered) */}
        <div className="absolute inset-0 z-0 flex items-center justify-center">
          <div className="w-full h-full opacity-80">
            <TileLayout chatOpen={chatOpen} />
          </div>
        </div>

        {/* Chat Transcript Area */}
        <div className="absolute bottom-0 left-0 right-0 z-10 p-4 max-h-[40%] overflow-y-auto">
          <div className="mx-auto max-w-3xl">
            <ChatTranscript
              hidden={!chatOpen}
              messages={messages}
              className="space-y-4"
            />
          </div>
        </div>
      </div>

      {/* Control Bar */}
      <div className="relative z-50 bg-card/80 border-t border-primary/20 backdrop-blur-md">
        <div className="mx-auto flex w-full max-w-3xl flex-col gap-4 p-4 pb-6">
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1">
              <AgentControlBar controls={controls} onChatOpenChange={setChatOpen} />
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleRestart}
              className="text-muted-foreground hover:text-primary hover:bg-primary/10 rounded-full"
              title="Restart Session"
            >
              <ArrowClockwise className="h-6 w-6" />
            </Button>
          </div>

          <div className="text-center">
            <p className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase">
              The Tank • Powered by LiveKit
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
