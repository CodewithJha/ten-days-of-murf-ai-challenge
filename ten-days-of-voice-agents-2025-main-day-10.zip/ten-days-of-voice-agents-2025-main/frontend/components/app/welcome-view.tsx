'use client';

import { useState } from 'react';
import { Button } from '@/components/livekit/button';
import { CurrencyDollar } from '@phosphor-icons/react/dist/ssr';

interface WelcomeViewProps {
  onConnect: (userName: string) => void;
}

export function WelcomeView({ onConnect }: WelcomeViewProps) {
  const [name, setName] = useState('');

  const handleConnect = () => {
    if (name.trim()) {
      onConnect(name);
    }
  };

  return (
    <div className="flex h-full w-full flex-col items-center justify-center bg-background text-foreground p-4 shark-gradient">
      <div className="flex flex-col items-center gap-8 max-w-md w-full text-center">
        <div className="flex flex-col items-center gap-2">
          <div className="h-24 w-24 rounded-full bg-primary flex items-center justify-center shadow-lg shadow-primary/20 border-2 border-primary">
            <CurrencyDollar size={48} weight="fill" className="text-background" />
          </div>
          <h1 className="text-5xl font-black tracking-tighter text-gold font-serif">
            THE TANK
          </h1>
          <p className="text-muted-foreground text-lg">
            Pitch your idea to the Shark.
          </p>
        </div>

        <div className="w-full flex flex-col gap-4">
          <div className="flex flex-col gap-2 text-left">
            <label htmlFor="name" className="text-sm font-bold text-gold uppercase tracking-wider">
              Entrepreneur Name
            </label>
            <input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your name..."
              className="w-full rounded-xl border-2 border-primary/30 bg-card px-4 py-3 text-lg font-bold text-foreground placeholder-muted-foreground focus:border-primary focus:outline-none transition-colors"
              onKeyDown={(e) => e.key === 'Enter' && handleConnect()}
            />
          </div>

          <Button
            onClick={handleConnect}
            disabled={!name.trim()}
            className="w-full h-14 text-lg font-bold bg-primary hover:bg-primary/90 text-background rounded-xl shadow-lg shadow-primary/20 disabled:opacity-50 disabled:cursor-not-allowed uppercase tracking-wide"
          >
            Enter the Tank
          </Button>
        </div>

        <div className="text-xs text-muted-foreground font-medium uppercase tracking-widest">
          Are you ready to make a deal?
        </div>
      </div>
    </div>
  );
}
