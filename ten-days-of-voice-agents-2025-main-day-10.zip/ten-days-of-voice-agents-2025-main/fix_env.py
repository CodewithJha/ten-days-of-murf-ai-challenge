import os

def read_env(path):
    env = {}
    if os.path.exists(path):
        with open(path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    env[key.strip()] = value.strip()
    return env

def write_env(path, env):
    with open(path, 'w') as f:
        for key, value in env.items():
            f.write(f"{key}={value}\n")

def main():
    frontend_env_path = 'frontend/.env.local'
    backend_env_path = 'backend/.env.local'

    print(f"Reading from {frontend_env_path}...")
    frontend_env = read_env(frontend_env_path)
    
    print(f"Reading from {backend_env_path}...")
    backend_env = read_env(backend_env_path)

    # Update backend env with LiveKit credentials from frontend
    keys_to_sync = ['LIVEKIT_URL', 'LIVEKIT_API_KEY', 'LIVEKIT_API_SECRET']
    updated = False
    for key in keys_to_sync:
        if key in frontend_env:
            if backend_env.get(key) != frontend_env[key]:
                print(f"Updating {key} in backend...")
                backend_env[key] = frontend_env[key]
                updated = True
            else:
                print(f"{key} is already in sync.")
        else:
            print(f"Warning: {key} not found in frontend env.")

    if updated:
        print(f"Writing updates to {backend_env_path}...")
        write_env(backend_env_path, backend_env)
        print("Backend environment updated.")
    else:
        print("No updates needed.")

if __name__ == "__main__":
    main()
