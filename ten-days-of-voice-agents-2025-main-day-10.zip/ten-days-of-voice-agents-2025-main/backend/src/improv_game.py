import random
from typing import List, Dict, Optional
from dataclasses import dataclass, field

@dataclass
class ImprovState:
    player_name: Optional[str] = None
    current_round: int = 0
    max_rounds: int = 3
    rounds: List[Dict[str, str]] = field(default_factory=list)
    phase: str = "intro"  # "intro", "awaiting_improv", "reacting", "done"

class ImprovGame:
    def __init__(self):
        self.state = ImprovState()
        self.scenarios = [
            "You are a time-travelling tour guide explaining modern smartphones to someone from the 1800s.",
            "You are a restaurant waiter who must calmly tell a customer that their order has escaped the kitchen.",
            "You are a customer trying to return an obviously cursed object to a very skeptical shop owner.",
            "You are a cat trying to convince a dog to let you share the bed.",
            "You are a superhero whose only power is making toast perfectly, trying to join the Avengers.",
            "You are an alien trying to order a pizza but you only know words from Shakespeare plays.",
            "You are a detective interrogating a suspect who is clearly a mime.",
            "You are a ghost trying to haunt a house but the new owners are really into it."
        ]
        self.current_scenario: Optional[str] = None

    def start_game(self, player_name: str):
        self.state.player_name = player_name
        self.state.current_round = 0
        self.state.rounds = []
        self.state.phase = "intro"

    def get_next_scenario(self) -> Optional[str]:
        if self.state.current_round >= self.state.max_rounds:
            self.state.phase = "done"
            return None
        
        self.state.current_round += 1
        self.state.phase = "awaiting_improv"
        self.current_scenario = random.choice(self.scenarios)
        return self.current_scenario

    def end_round(self, host_reaction: str):
        self.state.rounds.append({
            "scenario": self.current_scenario,
            "host_reaction": host_reaction
        })
        self.state.phase = "reacting"

    def get_summary(self) -> str:
        return f"That's a wrap! {self.state.player_name}, you made it through {self.state.max_rounds} rounds of pure chaos."
