from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import uvicorn

app = FastAPI(title="Shark Tank API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Deal(BaseModel):
    entrepreneur: str
    company: str
    ask_amount: int
    ask_equity: int
    valuation: int
    status: str # "Pitching", "Offer Made", "Deal", "No Deal"

# Mock database
deals = [
    Deal(entrepreneur="Mark", company="Cuban Eats", ask_amount=100000, ask_equity=10, valuation=1000000, status="Deal"),
    Deal(entrepreneur="Lori", company="Greiner Gadgets", ask_amount=50000, ask_equity=20, valuation=250000, status="No Deal"),
]

@app.get("/")
def read_root():
    return {"message": "Welcome to the Shark Tank API"}

@app.get("/deals", response_model=List[Deal])
def get_deals():
    return deals

@app.post("/deals")
def create_deal(deal: Deal):
    deals.append(deal)
    return deal

@app.get("/sharks")
def get_sharks():
    return [
        {"name": "Kevin O'Leary", "net_worth": "$400M", "specialty": "Royalties"},
        {"name": "Mark Cuban", "net_worth": "$4.6B", "specialty": "Tech"},
        {"name": "Barbara Corcoran", "net_worth": "$100M", "specialty": "Real Estate"},
        {"name": "Lori Greiner", "net_worth": "$150M", "specialty": "Retail"},
        {"name": "Robert Herjavec", "net_worth": "$200M", "specialty": "Cybersecurity"},
    ]

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
