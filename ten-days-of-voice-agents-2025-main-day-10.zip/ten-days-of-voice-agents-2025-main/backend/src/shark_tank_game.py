import logging
from typing import Optional, List

logger = logging.getLogger("shark-tank-game")

class SharkTankGame:
    def __init__(self):
        self.entrepreneur_name: Optional[str] = None
        self.stage: str = "intro"  # intro, pitch, valuation, negotiation, decision
        self.valuation: Optional[int] = None
        self.ask_amount: Optional[int] = None
        self.ask_equity: Optional[int] = None
        self.history: List[str] = []

    def start_pitch(self, name: str):
        self.entrepreneur_name = name
        self.stage = "pitch"
        self.history.append(f"Pitch started by {name}")
        logger.info(f"Pitch started for {name}")

    def set_ask(self, amount: int, equity: int):
        self.ask_amount = amount
        self.ask_equity = equity
        if equity > 0:
            self.valuation = int(amount / (equity / 100))
        self.stage = "valuation"
        self.history.append(f"Ask: ${amount} for {equity}% (Valuation: ${self.valuation})")
        logger.info(f"Ask set: {amount} for {equity}%")

    def make_offer(self, amount: int, equity: int):
        self.stage = "negotiation"
        self.history.append(f"Shark Offer: ${amount} for {equity}%")
        logger.info(f"Shark offer: {amount} for {equity}%")

    def im_out(self, reason: str):
        self.stage = "decision"
        self.history.append(f"Shark Out: {reason}")
        logger.info(f"Shark out: {reason}")

    def get_state(self):
        return {
            "entrepreneur_name": self.entrepreneur_name,
            "stage": self.stage,
            "valuation": self.valuation,
            "ask_amount": self.ask_amount,
            "ask_equity": self.ask_equity,
            "history": self.history
        }
