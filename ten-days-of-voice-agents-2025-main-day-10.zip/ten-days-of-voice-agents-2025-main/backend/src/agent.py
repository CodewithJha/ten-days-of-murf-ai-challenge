import logging
from pathlib import Path
from dotenv import load_dotenv
import os
import json
from datetime import datetime
from typing import Annotated, Dict, Any, Optional, List

# Load env vars
env_path = Path(__file__).parent.parent / ".env.local"
load_dotenv(dotenv_path=env_path)

from livekit.agents import (
    Agent,
    AgentSession,
    JobContext,
    JobProcess,
    MetricsCollectedEvent,
    RoomInputOptions,
    WorkerOptions,
    cli,
    metrics,
    function_tool,
    RunContext,
    llm,
)
from livekit.plugins import silero, google, deepgram, noise_cancellation, murf
from livekit.plugins.turn_detector.multilingual import MultilingualModel
from .shark_tank_game import SharkTankGame

logger = logging.getLogger("shark-tank-agent")

class SharkTankAgent(Agent):
    def __init__(self) -> None:
        self.game = SharkTankGame()
        super().__init__(
            instructions=self._get_instructions(),
        )

    def _get_instructions(self) -> str:
        return """
        You are a "Shark" investor on the show "The Tank".
        
        **PERSONA:**
        - You are tough, analytical, and direct.
        - You care deeply about numbers: Sales, Margins, Customer Acquisition Cost (CAC), and Valuation.
        - You are skeptical of high valuations without sales to back them up.
        - You use phrases like: "I'm out", "What's the valuation?", "Stop the madness", "You're dead to me".
        - However, you are also fair. If the numbers make sense, you will make an offer.
        
        **GAME FLOW:**
        1.  **Intro:** When the user joins, welcome them to "The Tank". Ask for their name and their company name.
        2.  **The Pitch:** Ask them to make their pitch. "Who are you and what is your ask?"
        3.  **The Numbers:**
            - Use `set_ask` when they state their ask (e.g., "$100k for 10%").
            - Immediately calculate the valuation. If it's too high (e.g., > $1M with no sales), grill them.
            - Ask about: Sales (Year to Date), Margins, Cost of Goods Sold.
        4.  **The Decision:**
            - If you don't like the business or the answers are bad, use `im_out` and explain why.
            - If you like it, use `make_offer` to make a counter-offer.
            
        **TOOLS:**
        - `start_pitch(name)`: Call this when the user provides their name.
        - `set_ask(amount, equity)`: Call this when the user states their ask.
        - `make_offer(amount, equity)`: Call this to make an offer.
        - `im_out(reason)`: Call this to drop out.
        
        **IMPORTANT:**
        - Be dramatic but professional.
        - Always check the math.
        """

    @function_tool
    async def start_pitch(self, name: str):
        """
        Start the pitch with the entrepreneur's name.
        """
        self.game.start_pitch(name)
        return f"Alright {name}, the floor is yours. Tell me about your business."

    @function_tool
    async def set_ask(self, amount: int, equity: int):
        """
        Record the entrepreneur's ask (amount in dollars, equity in percentage).
        """
        self.game.set_ask(amount, equity)
        valuation = self.game.valuation
        return f"So you're asking for ${amount} for {equity}%. That values your company at ${valuation}. That's a bold valuation. Do you have the sales to back that up?"

    @function_tool
    async def make_offer(self, amount: int, equity: int):
        """
        Make an investment offer to the entrepreneur.
        """
        self.game.make_offer(amount, equity)
        return f"I'm willing to offer you ${amount}, but I want {equity}% of the company. Take it or leave it."

    @function_tool
    async def im_out(self, reason: str):
        """
        Declare that you are out of the deal.
        """
        self.game.im_out(reason)
        return f"For that reason, {reason}, I'm out."

def prewarm(proc: JobProcess):
    try:
        logger.info("Starting prewarm...")
        proc.userdata["vad"] = silero.VAD.load()
        proc.userdata["stt"] = deepgram.STT(model="nova-3")
        proc.userdata["llm"] = google.LLM(model="gemini-2.5-flash")
        proc.userdata["tts"] = murf.TTS(
            model="FALCON",
            voice="Matthew", # A deep, authoritative voice fits a Shark
            style="Promo",
        )
        
        if not os.getenv("DEEPGRAM_API_KEY"):
            logger.error("DEEPGRAM_API_KEY is missing")
        if not os.getenv("GOOGLE_API_KEY"):
            logger.error("GOOGLE_API_KEY is missing")
            
        logger.info("Prewarm completed")
    except Exception as e:
        logger.error(f"Prewarm failed: {e}", exc_info=True)
        raise e

async def entrypoint(ctx: JobContext):
    try:
        logger.info("Entrypoint started")
        ctx.log_context_fields = {"room": ctx.room.name}
        
        agent = SharkTankAgent()
        
        session = AgentSession(
            stt=ctx.proc.userdata.get("stt") or deepgram.STT(model="nova-3"),
            llm=ctx.proc.userdata.get("llm") or google.LLM(model="gemini-2.5-flash"),
            tts=ctx.proc.userdata.get("tts") or murf.TTS(
                model="FALCON",
                voice="Matthew",
                style="Promo",
            ),
            turn_detection=ctx.proc.userdata.get("turn_detection") or MultilingualModel(),
            vad=ctx.proc.userdata["vad"],
            preemptive_generation=True,
        )
        
        usage_collector = metrics.UsageCollector()
        
        @session.on("metrics_collected")
        def _on_metrics_collected(ev: MetricsCollectedEvent):
            metrics.log_metrics(ev.metrics)
            usage_collector.collect(ev.metrics)

        async def log_usage():
            summary = usage_collector.get_summary()
            logger.info(f"Usage: {summary}")

        ctx.add_shutdown_callback(log_usage)

        logger.info("Starting session...")
        await session.start(
            agent=agent,
            room=ctx.room,
            room_input_options=RoomInputOptions(
                noise_cancellation=noise_cancellation.BVC(),
            ),
        )
        
        logger.info("Connecting to room...")
        await ctx.connect()
        logger.info("Connected to room")
        
        # Initial greeting
        participants = list(ctx.room.remote_participants.values())
        participant = participants[-1] if participants else None
        
        initial_greeting = "Welcome to The Tank. I'm looking for the next big thing."
        
        if participant and participant.name and participant.name != "user":
            agent.game.start_pitch(participant.name)
            initial_greeting += f" Hello {participant.name}. Step into the tank. What do you have for me?"
        else:
            initial_greeting += " Who are you? State your name."
            
        await session.say(initial_greeting, add_to_chat_ctx=True)
        logger.info("Initial greeting sent")

    except Exception as e:
        logger.error(f"Error in entrypoint: {e}")
        raise e

if __name__ == "__main__":
    cli.run_app(
        WorkerOptions(
            entrypoint_fnc=entrypoint, 
            prewarm_fnc=prewarm,
            agent_name="shark-tank-agent",
            ws_url=os.getenv("LIVEKIT_URL"),
            api_key=os.getenv("LIVEKIT_API_KEY"),
            api_secret=os.getenv("LIVEKIT_API_SECRET"),
        )
    )
