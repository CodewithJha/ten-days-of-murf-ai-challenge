import logging
from pathlib import Path
from dotenv import load_dotenv
import os
import json
from datetime import datetime
from typing import Annotated, Dict, Any, Optional, List

# Load env vars
env_path = Path(__file__).parent.parent / ".env.local"
load_dotenv(dotenv_path=env_path)

from livekit.agents import (
    Agent,
    AgentSession,
    JobContext,
    JobProcess,
    MetricsCollectedEvent,
    RoomInputOptions,
    WorkerOptions,
    cli,
    metrics,
    function_tool,
    RunContext,
    llm,
)
from livekit.plugins import silero, google, deepgram, noise_cancellation, murf
from livekit.plugins.turn_detector.multilingual import MultilingualModel

try:
    from src.cart import Cart
    from src.order_manager import OrderManager
except ImportError:
    from cart import Cart
    from order_manager import OrderManager

logger = logging.getLogger("grocery-agent")

# Load Catalog
CATALOG_PATH = Path(__file__).parent / "catalog.json"
try:
    with open(CATALOG_PATH, "r") as f:
        CATALOG = json.load(f)
    logger.info(f"Loaded catalog with {len(CATALOG)} items")
except Exception as e:
    logger.error(f"Failed to load catalog: {e}")
    CATALOG = []

class GroceryAgent(Agent):
    def __init__(self) -> None:
        super().__init__(
            instructions=self._get_instructions(),
        )
        self.cart = Cart()
        self.order_manager = OrderManager(orders_dir=str(Path(__file__).parent.parent / "orders"))
        self.catalog_lookup = {item["name"].lower(): item for item in CATALOG}

    def _get_instructions(self) -> str:
        return """
        You are a **Friendly Grocery Shopping Assistant** for **Zepto AI**.
        
        **YOUR GOAL:**
        Help users order food and groceries, manage their cart, and place orders.
        
        **CAPABILITIES:**
        1.  **Add Items:** Add specific items to the cart (e.g., "Add milk").
        2.  **Ingredients for Recipes:** Intelligently add multiple items for a dish (e.g., "Ingredients for a sandwich" -> Bread, PB, Jelly).
        3.  **Manage Cart:** Remove items, update quantities, or clear the cart.
        4.  **Check Cart:** List what's in the cart.
        5.  **Checkout:** Confirm the order and save it.

        **CATALOG:**
        You have access to a catalog of items (Groceries, Snacks, Prepared Food). 
        If a user asks for something not in the catalog, politely say you don't carry it but offer a similar item if available.

        **TONE:**
        - Friendly, helpful, and efficient.
        - Confirm actions clearly (e.g., "I've added organic milk to your cart.").
        - When the user says "that's all" or "place order", summarize the cart and ask for confirmation before placing it.

        **TOOLS:**
        - `add_to_cart`: Add items.
        - `remove_from_cart`: Remove items.
        - `view_cart`: Get current cart state.
        - `place_order`: Finalize the order.
        - `get_ingredients_for_dish`: Find items for a recipe.
        """

    @function_tool
    async def add_to_cart(
        self,
        ctx: RunContext,
        item_name: Annotated[str, "The name of the item to add"],
        quantity: Annotated[int, "The quantity to add"] = 1,
        notes: Annotated[str, "Any special notes (e.g., 'large size')"] = "",
    ):
        """Add an item to the cart. Tries to match item_name to catalog."""
        logger.info(f"Tool add_to_cart called: {item_name} x{quantity}")
        
        # Simple fuzzy match or direct lookup
        item_key = item_name.lower()
        matched_item = None
        
        # Exact match
        if item_key in self.catalog_lookup:
            matched_item = self.catalog_lookup[item_key]
        else:
            # Partial match
            for name, item in self.catalog_lookup.items():
                if item_key in name or name in item_key:
                    matched_item = item
                    break
        
        if not matched_item:
            return f"I couldn't find '{item_name}' in our catalog. We have: {', '.join(list(self.catalog_lookup.keys())[:5])}..."

        added_item = self.cart.add_item(
            item_id=matched_item["id"],
            name=matched_item["name"],
            price=matched_item["price"],
            quantity=quantity,
            notes=notes
        )
        
        return f"Added {quantity}x {matched_item['name']} to cart. Total: ${self.cart.get_total():.2f}"

    @function_tool
    async def remove_from_cart(
        self,
        ctx: RunContext,
        item_name: Annotated[str, "The name of the item to remove"],
    ):
        """Remove an item from the cart."""
        # Find item in cart by name
        item_id_to_remove = None
        for item in self.cart.items.values():
            if item_name.lower() in item.name.lower():
                item_id_to_remove = item.id
                break
        
        if item_id_to_remove:
            removed = self.cart.remove_item(item_id_to_remove)
            return f"Removed {removed.name} from your cart."
        else:
            return f"I couldn't find '{item_name}' in your cart."

    @function_tool
    async def view_cart(self, ctx: RunContext):
        """Get the current status of the cart."""
        return str(self.cart)

    @function_tool
    async def get_ingredients_for_dish(
        self,
        ctx: RunContext,
        dish_name: Annotated[str, "The name of the dish (e.g., 'sandwich', 'pasta')"],
    ):
        """Finds ingredients in the catalog for a specific dish and adds them to the cart."""
        logger.info(f"Tool get_ingredients_for_dish called: {dish_name}")
        dish = dish_name.lower()
        added_items = []

        # Simple hardcoded recipe logic (can be expanded)
        if "sandwich" in dish:
            # Bread, PB, Jelly
            for key in ["whole wheat bread", "creamy peanut butter", "strawberry preserves"]:
                if key in self.catalog_lookup:
                    item = self.catalog_lookup[key]
                    self.cart.add_item(item["id"], item["name"], item["price"], 1)
                    added_items.append(item["name"])
        
        elif "pasta" in dish or "spaghetti" in dish:
            # Pasta, Sauce, Cheese
            for key in ["spaghetti pasta", "marinara sauce", "parmesan cheese"]:
                if key in self.catalog_lookup:
                    item = self.catalog_lookup[key]
                    self.cart.add_item(item["id"], item["name"], item["price"], 1)
                    added_items.append(item["name"])
        
        elif "pizza" in dish:
             if "pepperoni pizza" in self.catalog_lookup:
                item = self.catalog_lookup["pepperoni pizza"]
                self.cart.add_item(item["id"], item["name"], item["price"], 1)
                added_items.append(item["name"])

        if added_items:
            return f"I've added the following ingredients for {dish_name}: {', '.join(added_items)}."
        else:
            return f"I'm not sure what ingredients you need for {dish_name}, or we don't carry them. You can ask for specific items."

    @function_tool
    async def place_order(self, ctx: RunContext):
        """Finalize the order and save it."""
        if not self.cart.items:
            return "Your cart is empty. I can't place an empty order."
        
        try:
            order_id = self.order_manager.place_order(self.cart)
            total = self.cart.get_total()
            self.cart.clear() # Clear cart after order
            return f"Order placed successfully! Order ID is {order_id}. Total amount: ${total:.2f}. Thank you for shopping with Zepto!"
        except Exception as e:
            logger.error(f"Failed to place order: {e}")
            return "I'm sorry, there was an issue placing your order. Please try again."

def prewarm(proc: JobProcess):
    try:
        logger.info("Starting prewarm...")
        proc.userdata["vad"] = silero.VAD.load()
        proc.userdata["stt"] = deepgram.STT(model="nova-3")
        # proc.userdata["turn_detection"] = MultilingualModel()
        
        if not os.getenv("DEEPGRAM_API_KEY"):
            logger.error("DEEPGRAM_API_KEY is missing")
        if not os.getenv("GOOGLE_API_KEY"):
            logger.error("GOOGLE_API_KEY is missing")
            
        logger.info("Prewarm completed")
    except Exception as e:
        logger.error(f"Prewarm failed: {e}", exc_info=True)
        raise e

async def entrypoint(ctx: JobContext):
    try:
        logger.info("Entrypoint started")
        ctx.log_context_fields = {"room": ctx.room.name}
        
        agent = GroceryAgent()
        
        session = AgentSession(
            stt=ctx.proc.userdata.get("stt") or deepgram.STT(model="nova-3"),
            llm=google.LLM(model="gemini-2.5-flash"),
            tts=deepgram.TTS(model="aura-helios-en"), 
            turn_detection=ctx.proc.userdata.get("turn_detection") or MultilingualModel(),
            vad=ctx.proc.userdata["vad"],
            preemptive_generation=True,
        )
        
        usage_collector = metrics.UsageCollector()
        
        @session.on("metrics_collected")
        def _on_metrics_collected(ev: MetricsCollectedEvent):
            metrics.log_metrics(ev.metrics)
            usage_collector.collect(ev.metrics)

        async def log_usage():
            summary = usage_collector.get_summary()
            logger.info(f"Usage: {summary}")

        ctx.add_shutdown_callback(log_usage)

        logger.info("Starting session...")
        await session.start(
            agent=agent,
            room=ctx.room,
            room_input_options=RoomInputOptions(
                noise_cancellation=noise_cancellation.BVC(),
            ),
        )
        
        logger.info("Connecting to room...")
        await ctx.connect()
        logger.info("Connected to room")
        
        # Initial greeting
        await session.say("Welcome to Zepto AI! I can help you order groceries, snacks, or find ingredients for your favorite meals. What can I get for you today?", add_to_chat_ctx=True)
        logger.info("Initial greeting sent")

    except Exception as e:
        logger.error(f"Error in entrypoint: {e}")
        raise e

if __name__ == "__main__":
    cli.run_app(
        WorkerOptions(
            entrypoint_fnc=entrypoint, 
            prewarm_fnc=prewarm,
            agent_name="freshmarket-agent",
            ws_url=os.getenv("LIVEKIT_URL"),
            api_key=os.getenv("LIVEKIT_API_KEY"),
            api_secret=os.getenv("LIVEKIT_API_SECRET"),
        )
    )

